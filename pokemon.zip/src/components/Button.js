import {useState} from 'react';


const Button = () => {
  const [result, setResult] = useState([]);

  const handleClick = (e) => {
    e.preventDefault();

    // bring in Pokemon API, use fetch
    fetch('https://pokeapi.co/api/v2/pokemon?limit=801')
    .then(response => response.json())
    .then(response => setResult(response.results))

  }

  return(
    <div>
      <button onClick={handleClick}>What are their names? </button>
        {result.map((pokemon, i) => (
          <p className="name" key={i}> {pokemon.name}</p>
          ))}
    </div>
  );
};

export default Button;


// {result !== null ? (
//   Object.keys(result).map((keyName, i) => (
//     <li key={i}> Index: {result.id} Name: {result.name}</li>
//   ))
// ) : null}


// OTHER SOLUTION:
// let ids = []
// for (var i = 1; i < 100; i++) {
//   ids.push(i)
// }

// let promises = ids.map(id => fetch('https://pokeapi.co/api/v2/pokemon/' +id))
// Promise.all(promises)
// .then(response => Promise.all(response.map(pokemon => pokemon.json())))
// .then(response => setResult(response))